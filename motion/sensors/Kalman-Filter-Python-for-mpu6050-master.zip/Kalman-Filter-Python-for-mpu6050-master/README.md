# KalmanFilterPython
This is a python library of Kalman filter and implementation of the same for the mpu6050 module
